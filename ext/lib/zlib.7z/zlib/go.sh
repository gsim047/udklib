# /bin/sh

if [[ !(-e zl.d) ]]
then
	g++ -I ~/include -std=c++11 -MM *.c > zl.d
fi

make -f Makefile.gmk install
