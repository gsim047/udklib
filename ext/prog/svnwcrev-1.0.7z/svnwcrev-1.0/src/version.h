#define SVNWCREV_VERSION "1.0, Build 9"
