#/bin/sh

if [[ !(-e jsontest.d) ]]
then
	g++ -c -std=c++11 -MM -I ~/include *.cpp > jsontest.d
fi

make -f jsontest.gmk
