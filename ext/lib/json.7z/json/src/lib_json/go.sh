#/bin/sh

if [[ !(-e json.d) ]]
then
	g++ -c -MM -I ~/include *.cpp > json.d
fi


make -f Makefile.gmk install
