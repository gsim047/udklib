#/bin/sh

if [[ !(-e jsontest.d) ]]
then
	g++ -c -MM -I ~/include *.cpp > jsontest.d
fi

make -f jsontest.gmk clean
